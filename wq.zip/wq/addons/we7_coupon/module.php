<?php
/**
 * 微擎卡券模块定义
 *
 * @author 微擎团队
 * @url 
 */
defined('IN_IA') or exit('Access Denied');

class We7_couponModule extends WeModule {

	public function settingsDisplay($settings) {message('请升级系统到最新版本');}


}